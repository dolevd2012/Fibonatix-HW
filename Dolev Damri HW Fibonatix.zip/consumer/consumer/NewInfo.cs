﻿using System;
using System.Collections.Generic;
using System.Text;

namespace consumer
{
    class newInfo
    {
        public String name { get; set; }
        public DateTime date { get; set; }
        public String profession { get; set; }

        public newInfo()
        {

        }

        public newInfo(string name, DateTime date,string profession)
        {
            this.name = name;
            this.date = date;
            this.profession = profession;
        }

        public override string ToString()
        {
            return "name = " + name + "\n" +
                   "Date = " + date + "\n" +
                   "Profession = " + profession + "\n";
        }
    }
}
