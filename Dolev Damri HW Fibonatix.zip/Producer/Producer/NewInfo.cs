﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Producer
{
    class NewInfo
    {
        public String name { get; set; }
        public DateTime date { get; set; }
        public String profession { get; set; }

        public NewInfo()
        {

        }

        public NewInfo(string name, DateTime date, string profession)
        {
            this.name = name;
            this.date = date;
            this.profession = profession;
        }

        public override string ToString()
        {
            return "name = " + name + "\n" +
                   "Date = " + date + "\n" +
                   "Profession = " + profession + "\n";
        }
    }
}
