﻿using System;


namespace Producer
{
    class Info
    {
        public String name { get; set; }
        public DateTime date { get; set; }
        public int age { get; set; }
        public String profession { get; set; }

        public Info()
        {

        }

        public Info(string name, DateTime date, int age, string profession)
        {
            this.name = name;
            this.date = date;
            this.age = age;
            this.profession = profession;
        }

        public override string ToString()
        {
            return "name = " + name + "\n" +
                   "age = " + age + "\n" +
                   "Date = " + date + "\n" +
                   "Profession = " + profession + "\n";
        }
    }

}
