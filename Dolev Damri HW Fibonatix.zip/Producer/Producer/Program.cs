﻿using System;
using System.Collections;
using System.Text;
using Newtonsoft.Json;
using RabbitMQ.Client;

namespace Producer
{
    class Program
    {
        static void Main(string[] args)
        {
            Info a = new Info("test1", DateTime.Now, 28, "Test1 sent");
            Info b = new Info("test2", DateTime.Now, 25, "Test2 sent");
            ArrayList arrayList = new ArrayList();
            arrayList.Add(a);
            arrayList.Add(b);
            uploadToQueueTaskManager(arrayList);
        }
        public static void uploadToQueueTaskManager(ArrayList arrayList)
        {
            ArrayList pushToRabbit = new ArrayList();
            foreach (Info item in arrayList)
            {
                pushToRabbit.Add(new NewInfo(item.name, item.date, item.profession));
            }
            arrayList.Clear();
            var factory = new ConnectionFactory
            {
                Uri = new Uri("amqp://guest:guest@localhost:5672")

            };
            using var connection = factory.CreateConnection();
            using var channel = connection.CreateModel();
            channel.QueueDeclare("task_queue",
                durable: true,
                exclusive: false,
                autoDelete: false,
                arguments: null

            );

            var body = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(pushToRabbit));
            var encoded = Encoding.UTF8.GetBytes((Convert.ToBase64String(body)));
            channel.BasicPublish("", "task_queue", null, encoded);
        }

    }
}
